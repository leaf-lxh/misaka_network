self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b988d23e87300ac3e1551d183f073fe9",
    "url": "/edit/index.html"
  },
  {
    "revision": "9eac37a1680ae16977c4",
    "url": "/edit/static/css/main.caccbf19.chunk.css"
  },
  {
    "revision": "3d9604605b9a8a2499b1",
    "url": "/edit/static/js/2.6c2f2328.chunk.js"
  },
  {
    "revision": "9eac37a1680ae16977c4",
    "url": "/edit/static/js/main.1f3d3da3.chunk.js"
  },
  {
    "revision": "be93fc9103a31e1ce48a",
    "url": "/edit/static/js/runtime~main.3358246a.js"
  }
]);