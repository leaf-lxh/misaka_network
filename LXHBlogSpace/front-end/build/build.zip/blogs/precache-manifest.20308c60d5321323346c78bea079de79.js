self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e188e9fc56f3a33de7dcb6a878783a1d",
    "url": "/blogs/index.html"
  },
  {
    "revision": "e147e30310c143282d7a",
    "url": "/blogs/static/css/2.07b4c11c.chunk.css"
  },
  {
    "revision": "54efc3bd933cc06ded3e",
    "url": "/blogs/static/css/main.e8a9cf71.chunk.css"
  },
  {
    "revision": "e147e30310c143282d7a",
    "url": "/blogs/static/js/2.32432032.chunk.js"
  },
  {
    "revision": "54efc3bd933cc06ded3e",
    "url": "/blogs/static/js/main.734502ac.chunk.js"
  },
  {
    "revision": "e34e8e7c1348909f90a4",
    "url": "/blogs/static/js/runtime~main.ea0323f4.js"
  }
]);