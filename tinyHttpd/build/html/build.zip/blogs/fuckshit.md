```python
from asshole import shit

eat(shit)
```



```
Can you guess what is this?
```



`hahaha`

